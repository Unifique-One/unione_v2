# Cloudflare Tunnel

O Quadlet lê `TUNNEL_TOKEN` de `/etc/unione/cloudflared/tunnel.env`.
Mantenha esse arquivo fora do Git e com permissão 0600.

No painel Cloudflare, configure `cloud.csphere.cloud` com destino `http://traefik:80`.
Adicione outros hostnames apenas depois de criar as rotas Traefik correspondentes.

Configure `admin.csphere.cloud` em Cloudflare Access e exija MFA na política/IdP.
Não publique o dashboard do Traefik.
